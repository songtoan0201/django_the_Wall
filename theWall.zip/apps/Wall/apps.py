from django.apps import AppConfig


class WallConfig(AppConfig):
    name = 'Wall'
